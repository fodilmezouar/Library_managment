package darhadit.parametre;

import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import darhadit.DataBase.DataBase;
import darhadit.alert.ClassAlert;
import java.net.InetAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Pc
 */
public class FXMLParametreController implements Initializable {

    DataBase base;
    
    @FXML
    private JFXTextField nom_utilisatuer;
    @FXML
    private JFXPasswordField mot_de_passe;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXCheckBox modifier_mdp;
    @FXML
    private JFXPasswordField mot_de_passe1;
    @FXML
    private JFXPasswordField mot_de_passe2;
    @FXML
    private JFXTextField adresse_ip;

    /**
     * Initializes the controller class.
     */
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        base = DataBase.getInstance();
        nom_utilisatuer.setText("مسؤول المكتبة");
        nom_utilisatuer.setEditable(false);
        modifier_mdp.setSelected(false);
        mot_de_passe1.setDisable(true);
        mot_de_passe2.setDisable(true);
        
        try{
            InetAddress AdresseMachineServeur = InetAddress.getLocalHost();
            adresse_ip.setText(AdresseMachineServeur.getHostAddress());
            adresse_ip.setEditable(false);
            //System.out.println(AdresseMachineServeur.getHostName().toString());
            System.out.println(AdresseMachineServeur.getHostAddress());
        } catch(UnknownHostException EX){
            System.out.println("erruer");
        }
        
        String qu = "select mot_de_passe,email from user";
        ResultSet rs = base.execQuery(qu);
        try {
            if(rs.next()){
                if (rs.getString("mot_de_passe").equals("")) {
                    email.setText(rs.getString("email"));
                }
            }
        } catch (SQLException ex) { 
        }
    }    

    @FXML
    private void verifier_mdp(ActionEvent event) {
        String qu = "select mot_de_passe,email from user";
        ResultSet rs = base.execQuery(qu);
        try {
            if(rs.next()){
                if (mot_de_passe.getText().equals(rs.getString("mot_de_passe"))) {
                    email.setText(rs.getString("email"));
                    //mot_de_passe.getStyleClass().add("true");
                }
                else{
                    vider_venetre(new ActionEvent());
                    //mot_de_passe.getStyleClass().add("false");
                }
            }
        } catch (SQLException ex) {
            
        } 
    }
    

    @FXML
    private void operation_modifier_mdp(ActionEvent event) {
        String qu = "select * from user";
        ResultSet rs = base.execQuery(qu);
        try {
            if(rs.next()){
                if (mot_de_passe.getText().equals(rs.getString("mot_de_passe")) ) {
                    if(modifier_mdp.isSelected())
                    {
                        mot_de_passe1.setDisable(false);
                        mot_de_passe2.setDisable(false);
                    }
                    else{
                        mot_de_passe1.setDisable(true);
                        mot_de_passe2.setDisable(true);
                        
                        mot_de_passe1.setText("");
                        mot_de_passe2.setText("");
                    }
                }
                else{
                    ClassAlert.errorAlert("يرجي إدخال كلمة السر", "خطأ");
                    if(modifier_mdp.isSelected()){
                        //mot_de_passe.getStyleClass().add("false");
                        modifier_mdp.setSelected(false);
                    }
                }
            }
        } catch (SQLException ex) {
            
        }    
    }

    @FXML
    private void vider_venetre(ActionEvent event) {
        mot_de_passe.setText("");
        email.setText("");
        modifier_mdp.setSelected(false);
        mot_de_passe1.setText("");
        mot_de_passe2.setText("");
        mot_de_passe1.setDisable(true);
        mot_de_passe2.setDisable(true);
        modifier_mdp.setSelected(false);
        mot_de_passe.getStyleClass().add("vide");
    }

    @FXML
    private void verifier_mdp_nouv(ActionEvent event) {
        if(mot_de_passe1.getText().equals(mot_de_passe2.getText())){
            //mot_de_passe2.getStyleClass().add("true");
            //mot_de_passe1.getStyleClass().add("true");
        }
        else{
            ClassAlert.errorAlert("يرجي تأكد من كلمة المرور الجديدة", "خطأ");
            //mot_de_passe2.getStyleClass().add("false");
            //mot_de_passe1.getStyleClass().add("false");
        }
    }

    @FXML
    private void enregistrer(ActionEvent event) {
        String qu1 = "select * from user";
        ResultSet rs = base.execQuery(qu1);
        try {
            if(rs.next()){
                if (mot_de_passe.getText().equals(rs.getString("mot_de_passe"))) {
                    if(!mot_de_passe1.getText().equals(mot_de_passe2.getText())){
                        ClassAlert.errorAlert("يرجي تأكد من كلمة المرور الجديدة", "خطأ");
                        return;
                    }
                    if(ClassAlert.confirmDialog("يرجى تأكيد لتغيير المعلومات", "تأكيد")){
                    String qu = "update user set email='"+email.getText()+"'";
                        if(modifier_mdp.isSelected()){
                            if(mot_de_passe1.getText().equals(mot_de_passe2.getText())){
                                qu += " , mot_de_passe='" + mot_de_passe2.getText()+"'"; 
                            }
                            else{
                                ClassAlert.errorAlert("يرجي تأكد من كلمة المرور الجديدة", "خطأ");
                                return;
                            }
                        }
                        base.execAction(qu);
                        ((Stage) mot_de_passe.getScene().getWindow()).close();
                        ClassAlert.infoAlert("تم تغيير المعلومات", "نجاح");
                    }
                    else {
                        ClassAlert.infoAlert("عمليةالتغيير ملغاة", "إلغاء");
                        ((Stage) mot_de_passe.getScene().getWindow()).close();
                    }
                }
                else{
                    ClassAlert.errorAlert("يرجي إدخال كلمة السر", "خطأ");
                }
            }
        } catch (SQLException ex) {
            
        }    
    }
    
}
